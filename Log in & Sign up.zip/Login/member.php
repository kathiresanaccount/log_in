<?php 
session_start();
if (isset($_SESSION['login'])) { ?>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1"> 
        <link rel="shortcut icon" type="image/x-icon" href="image\GUVI-LOGO.png"/>
        <link rel="stylesheet"  type="text/css" href="styles\bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="styles\stylesheet.css">
        <title>Member</title>
    </head>
    <body style="text-align:center;">
        <div class="row bg">
            <div class="col-md-2 menu" id="stu_details" style="text-align:center;">
               <div class="row nomargin">
                    <div class="col-12 padding"> </div>
                </div>
                <?php include "sidemenu.php" ?>   
            </div>
            <div class="col-md-10 content-area" style="text-align:center; overflow: auto" >
                <div class="row">
                 
                    <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-6">
                        </div>
                        <div class="col-md-3" style="margin-top:10px">
                            <img src="image/GUVI-LOGO.png" style="width: 270px;height: 100px">    
                        </div>
                    </div>
                  
            <div style="margin-left: 30px;" class="student_table" id="main8">
               
     <?php 
            $sqlconn = mysqli_connect("localhost", "root","");
            mysqli_select_db($sqlconn,'users');
               
           $USER=$_SESSION["login"];

           $query="SELECT * FROM `authorizedusers` WHERE Username='$USER'";
           
            $result=mysqli_query($sqlconn,$query);
             $row = mysqli_fetch_object($result);
                ?>
            <h1 class="welcome"> Hi <?php echo  $row->Full_name; ?></h1><br>
                <h3 class="welcome">Email :<?php echo  $row->Email ; ?></h3>
                <h3 class="welcome">Phone :<?php echo  $row->Mobile ; ?></h3>
                <!-- <h3 class="welcome">Age <input type="text" name="age" id= "age" onchange="agechange()" class="age"></h3> -->
</div>
<br>
</div>
            </div>

            </div>
        </div>

        
    </body>
</html>
<script src="js/jquery.min.js"></script>
    <script src="js/scipt.js"></script>
    <script type="text/javascript"></script>
<?php
}
else
{
    header('Location: index.php');
}
 ?>