<?php
session_start();
$username=$_POST["un"];
$password=$_POST["pwd"];
$sqlconn = mysqli_connect("localhost", "root","");
mysqli_select_db($sqlconn,'users');
$na="SELECT * FROM `authorizedusers` WHERE Username='$username' AND Password='$password'";
$ress = mysqli_query($sqlconn,$na);
$user_count = mysqli_num_rows($ress);
if ($user_count == 1) {
	$_SESSION["login"]=$username;
}
echo $user_count;
?>
