<?php
session_start();
$fullname=$_POST["fn"];
$username = $_POST["un"];
$email = $_POST["em"];
$mobile = $_POST["mb"];
$password=$_POST["pw"];
$sqlconn = mysqli_connect("localhost", "root","");
mysqli_select_db($sqlconn,'users');
$insert = "INSERT INTO `authorizedusers` (Full_name, Username, Password, Email, Mobile)
VALUES ('$fullname', '$username', '$password', '$email', '$mobile');";


if ($sqlconn->query($insert) === TRUE) {
	$_SESSION["login"]=$username;
    echo 0;

} else {
    echo 1;
}

?>
