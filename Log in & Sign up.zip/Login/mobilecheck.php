<?php
session_start();
$mobile=$_POST["mob"];
$sqlconn = mysqli_connect("localhost", "root","");
mysqli_select_db($sqlconn,'users');
$unc="SELECT * FROM `authorizedusers` WHERE Mobile='$mobile'";
$ress = mysqli_query($sqlconn,$unc);
$user_count = mysqli_num_rows($ress);
echo $user_count;
?>