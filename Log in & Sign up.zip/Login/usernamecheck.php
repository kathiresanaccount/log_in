<?php
session_start();
$username=$_POST["un"];
$sqlconn = mysqli_connect("localhost", "root","");
mysqli_select_db($sqlconn,'users');
$unc="SELECT * FROM `authorizedusers` WHERE Username='$username'";
$ress = mysqli_query($sqlconn,$unc);
$user_count = mysqli_num_rows($ress);
echo $user_count;
?>