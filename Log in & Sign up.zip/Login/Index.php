<?php
session_start();
if (isset($_SESSION["login"])) {
    header('Location: member.php');
}
else
{
?>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1"> 
        <link rel="shortcut icon" type="image/x-icon" href="image\GUVI-LOGO.png"/>
        <link rel="stylesheet"  type="text/css" href="styles\bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="styles\stylesheet.css">
        <title>Index</title>
    </head>
    <body style="text-align:center;" link="white">
        <div class="row ">
        <div class="col-md-9 banner " >
                <div class="slideshow-container" id="main">
        <img class="mySlides" src="image\slide1.jpg">
        <img class="mySlides" src="image\slide2.jpg">
        <img class="mySlides" src="image\slide3.jpg">
    </div>
</div>
            <div class="col-md-3 login" style="text-align:center;">
                <div class="row nomargin">
                    <div class="col-12 padding">
                        <div style="margin-left: 0%;" class="logo"></div> 
                    </div>
                    <div id="login-signup"> 
                        <div class="col-12 padding"> <button type="button" class="block" id="login">Log In</button></div>
               
                        <div class="col-12 padding"><button type="button" class="block" id="signup">Sign Up</button></div>
                    </div>
                </div>
                <div class="col-12">
                    <div id="login_">
                        <form class="centeralign">
                            <div class="login_ padding"> 
                                <input type="text" name="username" id="username" placeholder="User name" class="mb10 padding" style="width: 100%"><br>
                                <input type="Password" name="password" id="password" placeholder="Password" class="mb10 padding" style="width: 100%">
                                <br>
                                <button type="button"  class="submitbutton" onclick="login()">Log In</button>
                            </div>
                        </form>
                        <a href="#" id="back-to-user" type="button">back</a>
                    </div>
                </div>
                 <div class="col-12">
                    <div id="signup_">
                        <form class="centeralign">
                            <div class="signup_ padding"> 
                                <input type="text" name="fullname" id="fullname" placeholder="Full Name" class="mb10 padding" style="width: 100%">
                                <input type="text" name="username_1" id="username_1" placeholder="User Name" onchange="usernamecheck()" class="mb10 padding" style="width: 100%">
                                <input type="hidden" name="username_confirm" id="username_confirm"  value="1">
                                <input type="email" name="email" id="email" placeholder="Email" class="mb10 padding" style="width: 100%">
                                <input type="number" name="mobile" id="mobile" placeholder="mobile" onchange="mobilecheck()" class="mb10 padding" style="width: 100%">
                                <input type="hidden" name="mobile_confirm" id="mobile_confirm"  value="1">
                                <input type="Password" name="password_1" id="password_1" placeholder="Password" class="mb10 padding" style="width: 100%">
                                 <input type="Password" name="confirmPassword" id="confirmPassword" placeholder="Confirm Password" class="mb10 padding" style="width: 100%">

                                <br>
                                <button type="button"  class="submitbutton" onclick="signup()">Sign up</button>
                            </div>
                        </form>
                        <a href="#" id="back-to-login" type="button">back</a>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<script src="js/jquery.min.js"></script>
<script src="js/scipt.js"></script>
<script type="text/javascript"></script>
<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 4000); 
}
</script>
<?php
}
?>



