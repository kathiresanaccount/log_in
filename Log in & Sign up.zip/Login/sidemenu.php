  <div class="sidebar">  
                  
                     <div style="margin-left:60%;font-size: 20px;" class="logout"><a style="font-color: white" href="#" onclick="logout()" class="logoutlink">logout</a></div>
  </div>
       