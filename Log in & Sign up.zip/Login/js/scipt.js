
$("#login").click(function(){
    $("#login_").css('display', "block");
    $("#login-signup").css('display', "none");
})
$("#signup").click(function(){
    $("#signup_").css('display', "block");
    $("#login-signup").css('display', "none");
})
$("#back-to-user").click(function(){
    $("#login_").css('display', "none");
    $("#login-signup").css('display', "block");
})
$("#back-to-login").click(function() {
    $("#signup_").css('display', "none");
    $("#login-signup").css('display', "block");
})

    function login()
    {

        var un = $('#username').val();
        var pwd = $('#password').val();
       $.ajax({
        url : 'login_user.php',
        type : 'POST',
        data: 
        {
            'un' : un,
            'pwd' :pwd,
        },
        success : function(num){
           
        if(num==1)
        {   
                      $('#username').val('');
            $('#password').val('');
           window.location.href = "member.php";
       
        }
        else
        {
            $('#username').val('');
            $('#password').val('');
            alert("Incorrect username or password")
            
        }
        }

       })
    }


function logout()
{
  window.location.href="logout.php";
}

function usernamecheck() {

 var un =$('#username_1').val();
$.ajax({
     url : 'usernamecheck.php',
        type : 'POST',
data: 
        {
            'un' : un,
            
        },
        success : function(num){
        if(num == 1)
        {  
           alert("username already being used");
            document.getElementById("username_1").style.borderColor  = "red";
            $("#username_confirm").val("1");
           
        }
        else
        {
          document.getElementById("username_1").style.borderColor  = "inherit";
          $("#username_confirm").val("0");   
        }
        }

       })
}
function mobilecheck() {

 var mob =$('#mobile').val();
$.ajax({
     url : 'mobilecheck.php',
        type : 'POST',
data: 
        {
            'mob' : mob,
            
        },
        success : function(num){
        if(num == 1)
        {  
           alert("Mobile already being used");
            document.getElementById("mobile").style.borderColor  = "red";
            $("#mobile_confirm").val("1");
           
        }
        else
        {
          document.getElementById("mobile").style.borderColor  = "inherit";  
          $("#mobile_confirm").val("0"); 
        }
        }

       })
}
 function signup()
    {
        if( ($("#fullname").val()!='') && ($("#username_1").val() != '') && ($("#email").val() != '') && ($("#mobile").val() != '') && ($("#password_1").val() != '') ){
        if(  ($("#username_confirm").val() != 1) && ($("#mobile_confirm").val() != 1)){

            if($("#password_1").val() == $("#confirmPassword").val()){

                                   var fn = $('#fullname').val();
        var un = $('#username_1').val();
        var em = $('#email').val();
        var mb = $('#mobile').val(); 
        var pw = $('#password_1').val(); 
       $.ajax({
        url : 'signup_user.php',
        type : 'POST',
        data: 
        {
            'fn' : fn,
            'un' :un,
            'em' : em,
            'mb' :mb,
            'pw' : pw,
        },
        success : function(num){
           
        if(num==0)
        {   
           window.location.href = "member.php";
       
        }
        else
        {
            alert("unsuccess");
            
        }
        }

       })


        }else
        {
                alert('Password mis match');
                $("#password_1").css('border-color' ,'red');
                $("#confirmPassword").css('border-color' ,'red');
            }
        }
        else
        {
            alert('Please Re-enter the Wrong Values');
        }
}
    else
    {
        alert('Fill the missing Values');
    }
}


